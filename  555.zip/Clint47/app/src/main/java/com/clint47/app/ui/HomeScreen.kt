package com.clint47.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.clint47.app.BatteryState

private fun levelColor(level: Int) = when {
    level >= 50 -> Good
    level >= 20 -> Warn
    else -> Danger
}

private fun tempColor(c: Float) = when {
    c >= 40f -> Danger
    c >= 35f -> Warn
    else -> Good
}

@Composable
fun HomeScreen(state: BatteryState?, isPro: Boolean = false, onUpgrade: () -> Unit = {}) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Clint 47", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))

        if (state == null) {
            Text("Reading battery…", color = TextSoft, fontSize = 14.sp)
            return@Column
        }

        LevelRing(state)
        Spacer(Modifier.height(24.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard("Temperature", "%.1f".format(state.tempC), "°C", tempColor(state.tempC), Modifier.weight(1f))
            InfoCard("Voltage", "%.2f".format(state.voltageV), "V", Primary, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard("Current", "${state.currentMa}", "mA", Primary, Modifier.weight(1f))
            InfoCard("Health", state.health, "", if (state.health == "Good") Good else Warn, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard("Source", state.source, "", Primary, Modifier.weight(1f))
            InfoCard("Technology", state.technology, "", Primary, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        ProSection(isPro, onUpgrade)
    }
}

@Composable
private fun LevelRing(s: BatteryState) {
    val color = levelColor(s.level)
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(220.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 12.dp.toPx()
            val inset = stroke / 2
            val arcSize = Size(size.width - stroke, size.height - stroke)
            drawArc(
                color = SurfaceDark, startAngle = -90f, sweepAngle = 360f, useCenter = false,
                topLeft = Offset(inset, inset), size = arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round),
            )
            drawArc(
                color = color, startAngle = -90f, sweepAngle = 360f * s.level / 100f, useCenter = false,
                topLeft = Offset(inset, inset), size = arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round),
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${s.level}%", color = TextMain, fontSize = 48.sp, fontWeight = FontWeight.Bold)
            Text(s.status, color = TextSoft, fontSize = 14.sp)
        }
    }
}

@Composable
private fun InfoCard(title: String, value: String, unit: String, accent: Color, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(SurfaceDark, RoundedCornerShape(20.dp))
            .padding(16.dp),
    ) {
        Text(title, color = TextSoft, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, color = accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (unit.isNotEmpty()) {
                Spacer(Modifier.width(4.dp))
                Text(unit, color = TextSoft, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun ProSection(isPro: Boolean, onUpgrade: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(SurfaceDark, RoundedCornerShape(20.dp))
            .padding(16.dp),
    ) {
        if (isPro) {
            Text("Clint 47 Pro", color = Good, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Full history and advanced tools are unlocked.", color = TextSoft, fontSize = 14.sp)
        } else {
            Text("Unlock Clint 47 Pro", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Full charging history, health tracking and advanced tools. Subscription required.", color = TextSoft, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onUpgrade) { Text("Subscribe") }
        }
    }
}

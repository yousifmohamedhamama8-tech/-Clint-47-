package com.clint47.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.clint47.app.ui.Clint47Theme
import com.clint47.app.ui.HomeScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Clint47Theme {
                val ctx = LocalContext.current
                val flow = remember { batteryFlow(ctx) }
                val state by flow.collectAsState(initial = null)
                val isPro by remember { Entitlement.isPro }.collectAsState(initial = BuildConfig.PRO_UNLOCKED)
                HomeScreen(state, isPro = isPro, onUpgrade = { /* TODO: launch Play Billing */ })
            }
        }
    }
}

package com.clint47.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF0F1420)
val SurfaceDark = Color(0xFF1A2133)
val Primary = Color(0xFF5B8CFF)
val TextMain = Color(0xFFE8ECF5)
val TextSoft = Color(0xFF9AA6BF)
val Good = Color(0xFF3DDC97)
val Warn = Color(0xFFFFB020)
val Danger = Color(0xFFFF5C5C)

private val Scheme = darkColorScheme(
    primary = Primary,
    background = BgDark,
    surface = SurfaceDark,
    onBackground = TextMain,
    onSurface = TextMain,
)

@Composable
fun Clint47Theme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}

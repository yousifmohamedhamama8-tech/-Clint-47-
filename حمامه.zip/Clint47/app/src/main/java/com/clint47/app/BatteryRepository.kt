package com.clint47.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlin.math.abs

data class BatteryState(
    val level: Int,
    val charging: Boolean,
    val status: String,
    val source: String,
    val tempC: Float,
    val voltageV: Float,
    val currentMa: Int,
    val health: String,
    val technology: String,
)

/** Emits a new BatteryState every time Android broadcasts a battery change. */
fun batteryFlow(context: Context): Flow<BatteryState> = callbackFlow {
    val app = context.applicationContext
    val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, intent: Intent) {
            trySend(readBattery(app, intent))
        }
    }
    val sticky = app.registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    sticky?.let { trySend(readBattery(app, it)) }
    awaitClose { app.unregisterReceiver(receiver) }
}

fun readBattery(ctx: Context, i: Intent): BatteryState {
    val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
    val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0

    val statusCode = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
    val charging = statusCode == BatteryManager.BATTERY_STATUS_CHARGING ||
        statusCode == BatteryManager.BATTERY_STATUS_FULL
    val status = when (statusCode) {
        BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
        BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
        BatteryManager.BATTERY_STATUS_FULL -> "Full"
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
        else -> "Unknown"
    }

    val source = when (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
        BatteryManager.BATTERY_PLUGGED_AC -> "AC"
        BatteryManager.BATTERY_PLUGGED_USB -> "USB"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
        else -> "Battery"
    }

    val health = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
        BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
        else -> "Unknown"
    }

    // EXTRA_TEMPERATURE is in tenths of a degree C; EXTRA_VOLTAGE is in mV.
    val tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
    val voltageV = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) / 1000f

    // CURRENT_NOW: unit and sign differ between manufacturers.
    // Heuristic: very large values are microamps, so convert to mA; show magnitude only.
    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
    val currentMa = if (raw == Int.MIN_VALUE) 0 else {
        val a = abs(raw)
        if (a >= 10_000) a / 1000 else a
    }

    return BatteryState(
        level = pct,
        charging = charging,
        status = status,
        source = source,
        tempC = tempC,
        voltageV = voltageV,
        currentMa = currentMa,
        health = health,
        technology = i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "-",
    )
}

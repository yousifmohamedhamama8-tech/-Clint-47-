package com.clint47.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.clint47.app.ui.Clint47Theme
import com.clint47.app.ui.HomeScreen

class MainActivity : ComponentActivity() {

    private var notifOn by mutableStateOf(true)

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // Start the service either way; without permission the notification is just hidden.
            if (notifOn) startMonitor()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val prefs = getSharedPreferences("clint47", MODE_PRIVATE)
        notifOn = prefs.getBoolean("notif_on", true)
        if (notifOn) ensurePermissionThenStart()

        setContent {
            Clint47Theme {
                val ctx = LocalContext.current
                val flow = remember { batteryFlow(ctx) }
                val state by flow.collectAsState(initial = null)
                val isPro by remember { Entitlement.isPro }
                    .collectAsState(initial = BuildConfig.PRO_UNLOCKED)
                HomeScreen(
                    state = state,
                    isPro = isPro,
                    onUpgrade = { /* TODO: launch Play Billing */ },
                    notifOn = notifOn,
                    onNotifToggle = { on ->
                        notifOn = on
                        prefs.edit().putBoolean("notif_on", on).apply()
                        if (on) ensurePermissionThenStart()
                        else stopService(Intent(this@MainActivity, BatteryService::class.java))
                    },
                )
            }
        }
    }

    private fun ensurePermissionThenStart() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startMonitor()
        }
    }

    private fun startMonitor() {
        ContextCompat.startForegroundService(this, Intent(this, BatteryService::class.java))
    }
}

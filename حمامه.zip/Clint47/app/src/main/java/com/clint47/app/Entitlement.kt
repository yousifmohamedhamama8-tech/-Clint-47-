package com.clint47.app

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map

/**
 * Single source of truth for "is this user Pro?".
 * - owner flavor: always Pro (BuildConfig.PRO_UNLOCKED = true).
 * - store flavor: Pro only after a verified Google Play subscription.
 */
object Entitlement {
    private val subscribed = MutableStateFlow(false)

    val isPro: Flow<Boolean> = subscribed.map { BuildConfig.PRO_UNLOCKED || it }

    /** Call this from the Play Billing code once a purchase is verified (or expires). */
    fun setSubscribed(value: Boolean) {
        subscribed.value = value
    }
}
